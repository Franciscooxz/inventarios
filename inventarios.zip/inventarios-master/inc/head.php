<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>INVENTARIOS CHINCHILLA SANDOVAL SAS</title>
<link rel="stylesheet" href="./css/bulma.min.css">
<link rel="stylesheet" href="./css/estilos.css">